package PageBean;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class PageFactoryPayment {

	WebDriver driver;
	
	@FindBy(id="txtCardholderName")
	WebElement pfCardholder;
	
	@FindBy(name="debit")
	WebElement pfDebit;
	
	@FindBy(name="cvv")
	WebElement pfCvv;
	
	@FindBy(name="month")
	WebElement pfMonth;
	
	@FindBy(name="year")
	WebElement pfYear;
	
	@FindBy(id="btnPayment")
	WebElement pfButton;

	public PageFactoryPayment(WebDriver driver) {
		
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public WebElement getPfCardholder() {
		return pfCardholder;
	}

	public void setPfCardholder(String Cardholder) {
		pfCardholder.sendKeys(Cardholder);
	}

	public WebElement getPfDebit() {
		return pfDebit;
	}

	public void setPfDebit(String Debit) {
		pfDebit.sendKeys(Debit);
	}

	public WebElement getPfCvv() {
		return pfCvv;
	}

	public void setPfCvv(String Cvv) {
		pfCvv.sendKeys(Cvv);
	}

	public WebElement getPfMonth() {
		return pfMonth;
	}

	public void setPfMonth(String Month) {
		pfMonth.sendKeys(Month);
	}

	public WebElement getPfYear() {
		return pfYear;
	}

	public void setPfYear(String Year) {
		pfYear.sendKeys(Year);
	}

	public WebElement getPfButton() {
		return pfButton;
	}

	public void setPfButton() {
		pfButton.click();
	}
	
	
	
	
}
