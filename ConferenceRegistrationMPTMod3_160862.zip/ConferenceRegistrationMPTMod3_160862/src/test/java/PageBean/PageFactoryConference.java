package PageBean;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.sun.jna.Structure.ByValue;

public class PageFactoryConference {

	WebDriver driver;
	
	@FindBy(id="txtFirstName")
	WebElement pfFirstName;
	
	@FindBy(id="txtLastName")
	WebElement pfLastName;
	
	@FindBy(name="Email")
	WebElement pfEmail;
	
	@FindBy(id="txtPhone")
	WebElement pfContact;
	
	@FindBy(how=How.NAME,using="size")
	WebElement pfPeople;
	
	@FindBy(id="txtAddress1")
	WebElement pfBuildingName;
	
	@FindBy(id="txtAddress2")
	WebElement pfAreaName;
	
	@FindBy(name="city")
	WebElement pfCity;
	
	@FindBy(name="state")
	WebElement pfState;
	
	@FindBy(name="memberStatus")
	WebElement memStatus;
	
	@FindBy(xpath="html/body/form/table/tbody/tr[12]/td[2]/input")
	WebElement pfMember;
	
	@FindBy(xpath="html/body/form/table/tbody/tr[13]/td[2]/input")
	WebElement pfNonMember;
	
	
	@FindBy(linkText="Next")
	WebElement pfNext;

	public PageFactoryConference(WebDriver driver) {
	
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public WebElement getPfFirstName() {
		return pfFirstName;
	}

	public void setPfFirstName(String FirstName) {
		pfFirstName.sendKeys(FirstName);
	}

	public WebElement getPfLastName() {
		return pfLastName;
	}

	public void setPfLastName(String LastName) {
		pfLastName.sendKeys(LastName);
	}

	public WebElement getPfEmail() {
		return pfEmail;
	}

	public void setPfEmail(String Email) {
		pfEmail.sendKeys(Email);
	}

	public WebElement getPfContact() {
		return pfContact;
	}

	public void setPfContact(String Contact) {
		pfContact.sendKeys(Contact);
	}

	public WebElement getPfPeople() {
		return pfPeople;
	}

	public void setPfPeople(String People) {
		Select s=new Select(pfPeople);
		s.selectByVisibleText(People);
	}

	public WebElement getPfBuildingName() {
		return pfBuildingName;
	}

	public void setPfBuildingName(String BuildingName) {
		pfBuildingName.sendKeys(BuildingName);
	}

	public WebElement getPfAreaName() {
		return pfAreaName;
	}

	public void setPfAreaName(String AreaName) {
		pfAreaName.sendKeys(AreaName);
	}

	public WebElement getPfCity() {
		return pfCity;
	}

	public void setPfCity(String City) {
		Select s=new Select(pfCity);
		s.selectByVisibleText(City);
	}

	public WebElement getPfState() {
		return pfState;
	}

	public void setPfState(String State) {
		Select s=new Select(pfState);
		s.selectByVisibleText(State);
	}

	

	public WebElement getMemStatus() {
		return memStatus;
	}

	public void setMemStatus(WebElement memStatus) {
		this.memStatus = memStatus;
	}

	public WebElement getPfMember() {
		return pfMember;
	}

	public void setPfMember(String Member) {
		pfMember.sendKeys(Member);
	}

	public WebElement getPfNonMember() {
		return pfNonMember;
	}

	public void setPfNonMember(String NonMember) {
		pfNonMember.sendKeys(NonMember);;
	}

	public WebElement getPfNext() {
		return pfNext;
	}

	public void setPfNext() {
		pfNext.click();
	}
	
	public void MembershipStatus(String membership) {
		if(membership.equals("pfMember")) {
			pfMember.click();
		}else
		{
			pfNonMember.click();
		}
	}
	
	
}
