package Conference;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

import PageBean.PageFactoryConference;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefnConference {

	private WebDriver driver;
	private PageFactoryConference objpfconf;
	
	
	
	@Given("^user is on ConferenceRegistration page$")
	public void user_is_on_ConferenceRegistration_page() throws Throwable {
	   driver = new FirefoxDriver();
	   objpfconf = new PageFactoryConference(driver);
	   driver.get("file:///D:/BDD%20MPT%20case%20study/ConferenceRegistartion.html");
	}

	@Then("^check the title of the page$")
	public void check_the_title_of_the_page() throws Throwable {
	    String title = driver.getTitle();
	    if(title.equals("Conference Registartion")) {
	    	System.out.println("Title Matched");
	    }
	    else {
	    	System.out.println("Title Not Matched");
	    }
	    driver.close();
	}

	@When("^user leaves first name field empty$")
	public void user_leaves_first_name_field_empty() throws Throwable {
	    objpfconf.setPfFirstName("");
	    Thread.sleep(2000);
	    objpfconf.setPfNext();
	}

	@Then("^prompt user to fill the first name$")
	public void prompt_user_to_fill_the_first_name() throws Throwable {
	    String alert = driver.switchTo().alert().getText();
	    Thread.sleep(2000);
	    driver.switchTo().alert().accept();
	    System.out.println(alert);
	    driver.close();
	}

	@When("^user leaves last name field empty$")
	public void user_leaves_last_name_field_empty() throws Throwable {
	    objpfconf.setPfFirstName("Pratik");
		objpfconf.setPfLastName("");
	    Thread.sleep(2000);
	    objpfconf.setPfNext();
	}

	@Then("^prompt user to fill the last name$")
	public void prompt_user_to_fill_the_last_name() throws Throwable {
		String alert = driver.switchTo().alert().getText();
	    Thread.sleep(2000);
	    driver.switchTo().alert().accept();
	    System.out.println(alert);
	    driver.close();
	}

	@When("^user enters email in wrong format$")
	public void user_enters_email_in_wrong_format() throws Throwable {
	    objpfconf.setPfFirstName("Pratik");
	    objpfconf.setPfLastName("Borse");
	    objpfconf.setPfEmail("abcd");
	    Thread.sleep(2000);
	    objpfconf.setPfNext();
	}

	@Then("^prompt user to enter email in correct format$")
	public void prompt_user_to_enter_email_in_correct_format() throws Throwable {
		String alert = driver.switchTo().alert().getText();
	    Thread.sleep(2000);
	    driver.switchTo().alert().accept();
	    System.out.println(alert);
	    driver.close();
	}

	@When("^user leaves contact number field empty$")
	public void user_leaves_contact_number_field_empty() throws Throwable {
		objpfconf.setPfFirstName("Pratik");
	    objpfconf.setPfLastName("Borse");
	    objpfconf.setPfEmail("pratik.borse@capgemini.com");
	    objpfconf.setPfContact("");
	    Thread.sleep(2000);
	    objpfconf.setPfNext();
	}

	@Then("^prompt user to enter the contact number$")
	public void prompt_user_to_enter_the_contact_number() throws Throwable {
		String alert = driver.switchTo().alert().getText();
	    Thread.sleep(2000);
	    driver.switchTo().alert().accept();
	    System.out.println(alert);
	    driver.close();
	}

	@When("^user enters contact number in wrong format$")
	public void user_enters_contact_number_in_wrong_format() throws Throwable {
		objpfconf.setPfFirstName("Pratik");
	    objpfconf.setPfLastName("Borse");
	    objpfconf.setPfEmail("pratik.borse@capgemini.com");
	    objpfconf.setPfContact("123456");
	    Thread.sleep(2000);
	    objpfconf.setPfNext();
	}

	@Then("^prompt user to enter contact number in correct format$")
	public void prompt_user_to_enter_contact_number_in_correct_format() throws Throwable {
		String alert = driver.switchTo().alert().getText();
	    Thread.sleep(2000);
	    driver.switchTo().alert().accept();
	    System.out.println(alert);
	    driver.close();
	}

	@When("^user does not select the number of people attending$")
	public void user_does_not_select_the_number_of_people_attending() throws Throwable {
		objpfconf.setPfFirstName("Pratik");
	    objpfconf.setPfLastName("Borse");
	    objpfconf.setPfEmail("pratik.borse@capgemini.com");
	    objpfconf.setPfContact("9999999999");
	    Select s = new Select(objpfconf.getPfPeople());
	    s.deselectByValue("1");
	    s.deselectByValue("2");
	    s.deselectByValue("3");
	    s.deselectByValue("4");
	    s.deselectByValue("5");
	    Thread.sleep(2000);
	    objpfconf.setPfNext();
	}

	@Then("^prompt user to select the number of people$")
	public void prompt_user_to_select_the_number_of_people() throws Throwable {
		String alert = driver.switchTo().alert().getText();
	    Thread.sleep(2000);
	    driver.switchTo().alert().accept();
	    System.out.println(alert);
	    driver.close();
	}

	@When("^user leaves building name and room number field empty$")
	public void user_leaves_building_name_and_room_number_field_empty() throws Throwable {
		objpfconf.setPfFirstName("Pratik");
	    objpfconf.setPfLastName("Borse");
	    objpfconf.setPfEmail("pratik.borse@capgemini.com");
	    objpfconf.setPfContact("9999999999");
	    objpfconf.setPfPeople("3");
	    objpfconf.setPfBuildingName("");
	    Thread.sleep(2000);
	    objpfconf.setPfNext();
	}

	@Then("^prompt user to fill the building name and room number$")
	public void prompt_user_to_fill_the_building_name_and_room_number() throws Throwable {
		String alert = driver.switchTo().alert().getText();
	    Thread.sleep(2000);
	    driver.switchTo().alert().accept();
	    System.out.println(alert);
	    driver.close();
	}

	@When("^user leaves area name field empty$")
	public void user_leaves_area_name_field_empty() throws Throwable {
		objpfconf.setPfFirstName("Pratik");
	    objpfconf.setPfLastName("Borse");
	    objpfconf.setPfEmail("pratik.borse@capgemini.com");
	    objpfconf.setPfContact("9999999999");
	    objpfconf.setPfPeople("3");
	    objpfconf.setPfBuildingName("Manas-2E");
	    objpfconf.setPfAreaName("");
	    Thread.sleep(2000);
	    objpfconf.setPfNext();
	}

	@Then("^prompt user to fill the area name$")
	public void prompt_user_to_fill_the_area_name() throws Throwable {
		String alert = driver.switchTo().alert().getText();
	    Thread.sleep(2000);
	    driver.switchTo().alert().accept();
	    System.out.println(alert);
	    driver.close();
	}

	@When("^user does not select any city$")
	public void user_does_not_select_any_city() throws Throwable {
		objpfconf.setPfFirstName("Pratik");
	    objpfconf.setPfLastName("Borse");
	    objpfconf.setPfEmail("pratik.borse@capgemini.com");
	    objpfconf.setPfContact("9999999999");
	    objpfconf.setPfPeople("3");
	    objpfconf.setPfBuildingName("Manas-2E");
	    objpfconf.setPfAreaName("Hinjewadi");
	    objpfconf.setPfCity("Select City");
	    Thread.sleep(2000);
	    objpfconf.setPfNext();
	}

	@Then("^prompt user to select a city$")
	public void prompt_user_to_select_a_city() throws Throwable {
		String alert = driver.switchTo().alert().getText();
	    Thread.sleep(2000);
	    driver.switchTo().alert().accept();
	    System.out.println(alert);
	    driver.close();
	}

	@When("^user does not select any state$")
	public void user_does_not_select_any_state() throws Throwable {
		objpfconf.setPfFirstName("Pratik");
	    objpfconf.setPfLastName("Borse");
	    objpfconf.setPfEmail("pratik.borse@capgemini.com");
	    objpfconf.setPfContact("9999999999");
	    objpfconf.setPfPeople("3");
	    objpfconf.setPfBuildingName("Manas-2E");
	    objpfconf.setPfAreaName("Hinjewadi");
	    objpfconf.setPfCity("Pune");
	    objpfconf.setPfState("Select State");
	    Thread.sleep(2000);
	    objpfconf.setPfNext();
	}

	@Then("^prompt user to select a state$")
	public void prompt_user_to_select_a_state() throws Throwable {
		String alert = driver.switchTo().alert().getText();
	    Thread.sleep(2000);
	    driver.switchTo().alert().accept();
	    System.out.println(alert);
	    driver.close();
	}

	@When("^user does not select any membership status$")
	public void user_does_not_select_any_membership_status() throws Throwable {
		objpfconf.setPfFirstName("Pratik");
	    objpfconf.setPfLastName("Borse");
	    objpfconf.setPfEmail("pratik.borse@capgemini.com");
	    objpfconf.setPfContact("9999999999");
	    objpfconf.setPfPeople("3");
	    objpfconf.setPfBuildingName("Manas-2E");
	    objpfconf.setPfAreaName("Hinjewadi");
	    objpfconf.setPfCity("Pune");
	    objpfconf.setPfState("Maharashtra");
	    boolean b = objpfconf.getMemStatus().isSelected();
	    if(b==true) {
	    	System.out.println("Membership Status selected");
	    }
	    else {
	    	Thread.sleep(2000);
		    objpfconf.setPfNext();
	    }
	    
	}

	@Then("^prompt user to select a membership status$")
	public void prompt_user_to_select_a_membership_status() throws Throwable {
		String alert = driver.switchTo().alert().getText();
	    Thread.sleep(2000);
	    driver.switchTo().alert().accept();
	    System.out.println(alert);
	    driver.close();
	}

	@When("^user clicks on Next link$")
	public void user_clicks_on_Next_link() throws Throwable {
		objpfconf.setPfFirstName("Pratik");
	    objpfconf.setPfLastName("Borse");
	    objpfconf.setPfEmail("pratik.borse@capgemini.com");
	    objpfconf.setPfContact("9999999999");
	    objpfconf.setPfPeople("3");
	    objpfconf.setPfBuildingName("Manas-2E");
	    objpfconf.setPfAreaName("Hinjewadi");
	    objpfconf.setPfCity("Pune");
	    objpfconf.setPfState("Maharashtra");
	    objpfconf.MembershipStatus("pfmember");
	    Thread.sleep(2000);
	    objpfconf.setPfNext();
	}

	@Then("^prompt user that all data is valid and navigate to PaymentDetails page$")
	public void prompt_user_that_all_data_is_valid_and_navigate_to_PaymentDetails_page() throws Throwable {
		String alert = driver.switchTo().alert().getText();
	    Thread.sleep(2000);
	    driver.switchTo().alert().accept();
	    System.out.println(alert);
	    Thread.sleep(3000);
	    driver.close();
	}
}
