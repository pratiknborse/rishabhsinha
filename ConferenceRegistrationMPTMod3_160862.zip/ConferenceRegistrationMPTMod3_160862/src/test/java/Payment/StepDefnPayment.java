package Payment;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import PageBean.PageFactoryPayment;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefnPayment {

	private WebDriver driver;
	private PageFactoryPayment objpfpay;
	
	
	@Given("^user is on PaymentDetails page$")
	public void user_is_on_PaymentDetails_page() throws Throwable {
		driver = new FirefoxDriver();
		objpfpay = new PageFactoryPayment(driver);
		driver.get("file:///D:/BDD%20MPT%20case%20study/PaymentDetails.html");
	}

	@Then("^check the title of the page$")
	public void check_the_title_of_the_page() throws Throwable {
	    String title = driver.getTitle();
	    if(title.equals("Payment Details")) {
	    	System.out.println("Title Matches");
	    }
	    else {
	    	System.out.println("Title did not Match");
	    }
	}

	@When("^user leaves card holder name field empty$")
	public void user_leaves_card_holder_name_field_empty() throws Throwable {
	    objpfpay.setPfCardholder("");
	    Thread.sleep(2000);
	    objpfpay.setPfButton();
	}

	@Then("^prompt user to fill the card holder name$")
	public void prompt_user_to_fill_the_card_holder_name() throws Throwable {
	    String alert = driver.switchTo().alert().getText();
	    Thread.sleep(2000);
	    driver.switchTo().alert().accept();
	    System.out.println(alert);
	    driver.close();
	}

	@When("^user leaves debit card number field empty$")
	public void user_leaves_debit_card_number_field_empty() throws Throwable {
		 objpfpay.setPfCardholder("Pratik Borse");
		 objpfpay.setPfDebit("");
		 Thread.sleep(2000);
		 objpfpay.setPfButton();
	}

	@Then("^prompt user to fill the debit card number$")
	public void prompt_user_to_fill_the_debit_card_number() throws Throwable {
		String alert = driver.switchTo().alert().getText();
	    Thread.sleep(2000);
	    driver.switchTo().alert().accept();
	    System.out.println(alert);
	    driver.close();
	}

	@When("^user leaves cvv field empty$")
	public void user_leaves_cvv_field_empty() throws Throwable {
		objpfpay.setPfCardholder("Pratik Borse");
		 objpfpay.setPfDebit("123456789");
		 objpfpay.setPfCvv("");
		 Thread.sleep(2000);
		 objpfpay.setPfButton();
	}

	@Then("^prompt user to fill the cvv$")
	public void prompt_user_to_fill_the_cvv() throws Throwable {
		String alert = driver.switchTo().alert().getText();
	    Thread.sleep(2000);
	    driver.switchTo().alert().accept();
	    System.out.println(alert);
	    driver.close();
	}

	@When("^user leaves card expiration month field empty$")
	public void user_leaves_card_expiration_month_field_empty() throws Throwable {
		objpfpay.setPfCardholder("Pratik Borse");
		 objpfpay.setPfDebit("123456789");
		 objpfpay.setPfCvv("555");
		 objpfpay.setPfMonth("");
		 Thread.sleep(2000);
		 objpfpay.setPfButton();
	}

	@Then("^prompt user to fill the card expiration month$")
	public void prompt_user_to_fill_the_card_expiration_month() throws Throwable {
		String alert = driver.switchTo().alert().getText();
	    Thread.sleep(2000);
	    driver.switchTo().alert().accept();
	    System.out.println(alert);
	    driver.close();
	}

	@When("^user leaves card expiration year field empty$")
	public void user_leaves_card_expiration_year_field_empty() throws Throwable {
		objpfpay.setPfCardholder("Pratik Borse");
		 objpfpay.setPfDebit("123456789");
		 objpfpay.setPfCvv("555");
		 objpfpay.setPfMonth("03");
		 objpfpay.setPfYear("");
		 Thread.sleep(2000);
		 objpfpay.setPfButton();
	}

	@Then("^prompt user to fill the card expiration year$")
	public void prompt_user_to_fill_the_card_expiration_year() throws Throwable {
		String alert = driver.switchTo().alert().getText();
	    Thread.sleep(2000);
	    driver.switchTo().alert().accept();
	    System.out.println(alert);
	    driver.close();
	}

	@When("^user enters all valid data and clicks on Make Payment button$")
	public void user_enters_all_valid_data_and_clicks_on_Make_Payment_button() throws Throwable {
		objpfpay.setPfCardholder("Pratik Borse");
		 objpfpay.setPfDebit("123456789");
		 objpfpay.setPfCvv("555");
		 objpfpay.setPfMonth("03");
		 objpfpay.setPfYear("2020");
		 Thread.sleep(2000);
		 objpfpay.setPfButton();
	}

	@Then("^prompt user that booking is successful$")
	public void prompt_user_that_booking_is_successful() throws Throwable {
		String alert = driver.switchTo().alert().getText();
	    Thread.sleep(2000);
	    driver.switchTo().alert().accept();
	    System.out.println(alert);
	    driver.close();
	}
}
