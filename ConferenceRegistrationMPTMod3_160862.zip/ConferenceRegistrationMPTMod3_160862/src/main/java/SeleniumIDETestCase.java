

import java.util.regex.Pattern;
import java.util.concurrent.TimeUnit;
import org.junit.*;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.*;
import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;

public class SeleniumIDETestCase {
  private WebDriver driver;
  private String baseUrl;
  private boolean acceptNextAlert = true;
  private StringBuffer verificationErrors = new StringBuffer();

  @Before
  public void setUp() throws Exception {
    driver = new FirefoxDriver();
    baseUrl = "http://change-this-to-the-site-you-are-testing/";
    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
  }

  @Test
  public void testSeleniumIDETestCase() throws Exception {
    driver.get("file:///D:/BDD%20MPT%20case%20study/ConferenceRegistartion.html");
    try {
      assertEquals("Conference Registartion", driver.getTitle());
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
    driver.findElement(By.linkText("Next")).click();
    try {
      assertEquals("Please fill the First Name", closeAlertAndGetItsText());
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
    driver.findElement(By.id("txtFirstName")).click();
    driver.findElement(By.id("txtFirstName")).clear();
    driver.findElement(By.id("txtFirstName")).sendKeys("Pratik");
    driver.findElement(By.linkText("Next")).click();
    try {
      assertEquals("Please fill the Last Name", closeAlertAndGetItsText());
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
    driver.findElement(By.id("txtLastName")).click();
    driver.findElement(By.id("txtLastName")).clear();
    driver.findElement(By.id("txtLastName")).sendKeys("Borse");
    driver.findElement(By.linkText("Next")).click();
    try {
      assertEquals("Please fill the Email", closeAlertAndGetItsText());
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
    driver.findElement(By.id("txtEmail")).click();
    driver.findElement(By.id("txtEmail")).clear();
    driver.findElement(By.id("txtEmail")).sendKeys("abcd");
    driver.findElement(By.linkText("Next")).click();
    try {
      assertEquals("Please enter valid Email Id.", closeAlertAndGetItsText());
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
    driver.findElement(By.id("txtEmail")).click();
    driver.findElement(By.id("txtEmail")).clear();
    driver.findElement(By.id("txtEmail")).sendKeys("pratik.borse@capgemini.com");
    driver.findElement(By.linkText("Next")).click();
    try {
      assertEquals("Please fill the Contact No.", closeAlertAndGetItsText());
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
    driver.findElement(By.id("txtPhone")).click();
    driver.findElement(By.id("txtPhone")).clear();
    driver.findElement(By.id("txtPhone")).sendKeys("123456789");
    driver.findElement(By.linkText("Next")).click();
    try {
      assertEquals("Please enter valid Contact no.", closeAlertAndGetItsText());
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
    driver.findElement(By.id("txtPhone")).click();
    driver.findElement(By.id("txtPhone")).clear();
    driver.findElement(By.id("txtPhone")).sendKeys("9999999999");
    driver.findElement(By.linkText("Next")).click();
    try {
      assertEquals("Please fill the Number of people attending", closeAlertAndGetItsText());
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
    new Select(driver.findElement(By.name("size"))).selectByVisibleText("3");
    driver.findElement(By.cssSelector("option[value=\"three\"]")).click();
    driver.findElement(By.linkText("Next")).click();
    try {
      assertEquals("Please fill the Building & Room No", closeAlertAndGetItsText());
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
    driver.findElement(By.id("txtAddress1")).click();
    driver.findElement(By.id("txtAddress1")).clear();
    driver.findElement(By.id("txtAddress1")).sendKeys("Manas-2E");
    driver.findElement(By.linkText("Next")).click();
    try {
      assertEquals("Please fill the Area name", closeAlertAndGetItsText());
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
    driver.findElement(By.id("txtAddress2")).click();
    driver.findElement(By.id("txtAddress2")).clear();
    driver.findElement(By.id("txtAddress2")).sendKeys("Hinjewadi");
    driver.findElement(By.linkText("Next")).click();
    try {
      assertEquals("Please select city", closeAlertAndGetItsText());
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
    //driver.findElement(By.name("city")).click();
    new Select(driver.findElement(By.name("city"))).selectByVisibleText("Pune");
    //driver.findElement(By.cssSelector("option[value=\"Pune\"]")).click();
    driver.findElement(By.linkText("Next")).click();
    try {
      assertEquals("Please select state", closeAlertAndGetItsText());
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
    //driver.findElement(By.name("state")).click();
    new Select(driver.findElement(By.name("state"))).selectByVisibleText("Maharashtra");
    //driver.findElement(By.cssSelector("option[value=\"Maharashtra\"]")).click();
    driver.findElement(By.linkText("Next")).click();
    try {
      assertEquals("Please Select MemeberShip status", closeAlertAndGetItsText());
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
    driver.findElement(By.name("memberStatus")).click();
    driver.findElement(By.linkText("Next")).click();
    try {
      assertEquals("Personal details are validated.", closeAlertAndGetItsText());
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
    driver.get("file:///D:/BDD%20MPT%20case%20study/PaymentDetails.html");
    try {
      assertEquals("Payment Details", driver.getTitle());
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
    driver.findElement(By.id("btnPayment")).click();
    try {
      assertEquals("Please fill the Card holder name", closeAlertAndGetItsText());
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
    driver.findElement(By.id("txtCardholderName")).clear();
    driver.findElement(By.id("txtCardholderName")).sendKeys("Pratik Borse");
    driver.findElement(By.id("btnPayment")).click();
    try {
      assertEquals("Please fill the Debit card Number", closeAlertAndGetItsText());
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
    driver.findElement(By.id("txtDebit")).clear();
    driver.findElement(By.id("txtDebit")).sendKeys("123456789");
    driver.findElement(By.id("btnPayment")).click();
    try {
      assertEquals("Please fill the CVV", closeAlertAndGetItsText());
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
    driver.findElement(By.id("txtCvv")).clear();
    driver.findElement(By.id("txtCvv")).sendKeys("555");
    driver.findElement(By.id("btnPayment")).click();
    try {
      assertEquals("Please fill expiration month", closeAlertAndGetItsText());
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
    driver.findElement(By.id("txtMonth")).clear();
    driver.findElement(By.id("txtMonth")).sendKeys("02");
    driver.findElement(By.id("btnPayment")).click();
    try {
      assertEquals("Please fill the expiration year", closeAlertAndGetItsText());
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
    driver.findElement(By.id("txtYear")).clear();
    driver.findElement(By.id("txtYear")).sendKeys("2020");
    driver.findElement(By.id("btnPayment")).click();
    try {
      assertEquals("Conference Room Booking successfully done!!!", closeAlertAndGetItsText());
    } catch (Error e) {
      verificationErrors.append(e.toString());
    }
  }

  @After
  public void tearDown() throws Exception {
    driver.quit();
    String verificationErrorString = verificationErrors.toString();
    if (!"".equals(verificationErrorString)) {
      fail(verificationErrorString);
    }
  }

  private boolean isElementPresent(By by) {
    try {
      driver.findElement(by);
      return true;
    } catch (NoSuchElementException e) {
      return false;
    }
  }

  private boolean isAlertPresent() {
    try {
      driver.switchTo().alert();
      return true;
    } catch (NoAlertPresentException e) {
      return false;
    }
  }

  private String closeAlertAndGetItsText() {
    try {
      Alert alert = driver.switchTo().alert();
      String alertText = alert.getText();
      if (acceptNextAlert) {
        alert.accept();
      } else {
        alert.dismiss();
      }
      return alertText;
    } finally {
      acceptNextAlert = true;
    }
  }
}
